from be import serve

if __name__ == "__main__":
    serve.be_run()
